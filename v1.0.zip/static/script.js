const chatMessages = document.getElementById('chat-messages');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const toastEl = document.getElementById('toast');
const toast = new bootstrap.Toast(toastEl);

userInput.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = (this.scrollHeight) + 'px';
});

userInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
});

sendBtn.addEventListener('click', sendMessage);

function addMessage(text, isUser = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isUser ? 'message-user' : 'message-ai'}`;
    
    const now = new Date();
    const timeStr = `${now.getHours()}:${now.getMinutes().toString().padStart(2, '0')}`;
    
    messageDiv.innerHTML = `
        <div class="message-content">${isUser ? escapeHtml(text) : escapeHtml(text).replace(/\n/g, '<br>')}</div>
        <div class="message-time">${timeStr}</div>
        ${!isUser ? `
            <button class="btn btn-sm copy-btn" onclick="copyText(this)">
                <i class="fas fa-copy me-1"></i>Копировать эпик
            </button>
        ` : ''}
    `;
    
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function addErrorMessage(text) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'message message-ai';
    errorDiv.innerHTML = `
        <div class="error-message">
            <i class="fas fa-exclamation-triangle me-2"></i>${escapeHtml(text)}
        </div>
        <div class="message-time">${new Date().getHours()}:${new Date().getMinutes().toString().padStart(2, '0')}</div>
    `;
    chatMessages.appendChild(errorDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function escapeHtml(unsafe) {
    if (!unsafe) return '';
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function setLoading(isLoading) {
    if (isLoading) {
        sendBtn.disabled = true;
        sendBtn.innerHTML = '<div class="loading"></div>';
        userInput.disabled = true;
    } else {
        sendBtn.disabled = false;
        sendBtn.innerHTML = '<i class="fas fa-paper-plane"></i>';
        userInput.disabled = false;
    }
}

async function sendMessage() {
    const text = userInput.value.trim();
    
    if (!text || text.length < 10) {
        alert('Напиши подробнее (минимум 10 символов)');
        return;
    }
    
    if (text.length > 2000) {
        alert('Слишком длинно (максимум 2000 символов)');
        return;
    }
    
    addMessage(text, true);
    userInput.value = '';
    userInput.style.height = 'auto';
    
    const loadingDiv = document.createElement('div');
    loadingDiv.className = 'message message-ai';
    loadingDiv.innerHTML = `
        <div class="message-content text-center py-3">
            <div class="loading mb-3"></div>
            <div style="color: var(--text-secondary); font-size: 0.95rem; font-weight: 400;">
                <i class="fas fa-robot me-2" style="color: var(--accent-color);"></i>
                ShezGard Bot думает
                <span class="typing-indicator"></span>
                <span class="typing-indicator"></span>
                <span class="typing-indicator"></span>
            </div>
        </div>
    `;
    chatMessages.appendChild(loadingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    setLoading(true);
    
    try {
        const response = await fetch('/api/generate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ description: text }),
        });
        
        if (loadingDiv.parentNode) {
            chatMessages.removeChild(loadingDiv);
        }
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.error || `Ошибка сервера: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.epic) {
            addMessage(data.epic);
        } else {
            throw new Error('Сервер не вернул поле "epic"');
        }
    } catch (error) {
        console.error('Ошибка при генерации:', error);
        
        if (loadingDiv.parentNode) {
            chatMessages.removeChild(loadingDiv);
        }
        
        addErrorMessage(`❌ ${error.message || 'Неизвестная ошибка'}`);
    } finally {
        setLoading(false);
    }
}

function copyText(button) {
    const messageDiv = button.closest('.message');
    const textElement = messageDiv.querySelector('.message-content');
    const text = textElement.innerText || textElement.textContent;
    
    navigator.clipboard.writeText(text).then(() => {
        const originalText = button.innerHTML;
        button.innerHTML = '<i class="fas fa-check me-1"></i>Скопировано!';
        button.style.background = 'linear-gradient(135deg, var(--accent-color), #5a4ae9)';
        button.style.color = 'white';
        button.style.borderColor = 'transparent';
        
        setTimeout(() => {
            button.innerHTML = originalText;
            button.style.background = '';
            button.style.color = '';
            button.style.borderColor = '';
        }, 2000);
    }).catch(err => {
        console.error('Ошибка копирования:', err);
        alert('Не удалось скопировать текст');
    });
}

window.addEventListener('load', () => {
    userInput.focus();
});