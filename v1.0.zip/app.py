import os
import logging
from typing import Optional

from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import httpx
from dotenv import load_dotenv

# Загружаем переменные окружения
load_dotenv()

# Настройка логирования
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Системный промпт (улучшенная версия для развёрнутых эпиков)
SYSTEM_PROMPT = """Ты — опытный системный аналитик и техлид в команде разработки iiko. Твоя специализация — интеграция с ЕГАИС, система маркировки и архитектура сервисов (ServiceApp, УТМ, iikoFront).

Твоя задача — на основе краткого описания пользователя создать РАЗВЁРНУТЫЙ, ДЕТАЛИЗИРОВАННЫЙ эпик по строгому шаблону. Не ограничивайся шаблонными фразами — дополняй реалистичными деталями из предметной области.

🔥 КЛЮЧЕВЫЕ ПРАВИЛА:
1. СОХРАНЯЙ СТРУКТУРУ шаблона дословно (заголовки ## 1., ## 2. и т.д.)
2. ПИШИ РАЗВЁРНУТО — каждый раздел должен содержать 3-5 содержательных пунктов или абзацев
3. ДОБАВЛЯЙ РЕАЛИСТИЧНЫЕ ДЕТАЛИ:
   - Конкретные метрики: "~40% касс", "30-секундный простой", "1–2 раза в месяц"
   - Названия компонентов: SAHelperService, УТМ 4.2.0, контроллер УТМ, Прокси Агент
   - Технические ограничения: ".NET Framework 4.7.2 на x32", "Named Pipes IPC", "Windows Event Log"
   - Бизнес-контекст: "высокая проходимость", "час пик", "риск потери продаж"
4. ИСПОЛЬЗУЙ ПРОФЕССИОНАЛЬНЫЙ ТОН с элементами сторителлинга:
   - Не "Проблема: не работает" → а "Клиент на x32 пытается установить ServiceApp → получает ошибку несовместимости"
   - Добавляй причинно-следственные связи: "Из-за отсутствия... → возникает... → что приводит к..."
5. ФОРМАТИРУЙ ТАБЛИЦЫ КОРРЕКТНО (разделитель |)
6. ОТВЕТ НА РУССКОМ — без комментариев вне шаблона

💡 ПРИМЕР КАЧЕСТВА (уровень детализации):
Вместо: "ServiceApp не запускается на 32-битных системах"
Пиши: "На текущий момент **ServiceApp** существует только в 64-битной версии (`x64`). Значительная часть клиентской базы (~40% касс) использует **32-битные версии Windows**, где установка невозможна из-за архитектурного несоответствия. Это исключает часть клиентов из автоматизации диагностики УТМ и создаёт нагрузку на ТП."

Шаблон эпика (СТРОГО СОХРАНЯЙ ЭТУ СТРУКТУРУ):
## 1. Вводная
[Развёрнутое описание проблемы с бизнес-воздействием, метриками, контекстом]

## 2. Основные цели и текущие проблемы
|Проблема|Последствия|Частота (по данным ТП / релизов)|
|-|-|-|
|[Конкретная проблема с деталями]|[Бизнес- и технические последствия]|[Метрика: ~40% касс, 1–2 раза в месяц и т.д.]|

|Цель|Измеримый результат|
|-|-|
|[Цель с техническими деталями]|[Конкретный измеримый результат с цифрами]|

## 3. User Story
- *Я, как [конкретная роль: владелец кассы / администратор / разработчик], хочу [конкретное действие], чтобы [бизнес-ценность с деталями].*
- *Я, как [другая роль], хочу [действие], чтобы [ценность].*

## 4. Текущий user case
### **Боли:**
- [Боль 1 с описанием воздействия]
- [Боль 2 с примером из практики]

### **Последовательность действий:**
1. [Шаг 1: кто что делает, с контекстом]
2. [Шаг 2: реакция системы / пользователя]
3. [Шаг 3: итоговый результат]

### **Итоговые проблемы:**
- [Системная проблема с бизнес-воздействием]

## 5. Предполагаемый user case
[Развёрнутое описание нового процесса: как пользователь взаимодействует с системой, какие автоматизации появляются, как устраняются боли. Добавляй технические детали: "через SAHelperService", "с использованием Named Pipes" и т.д.]

## 6. Функционал
### **Система должна:**
- [Функция 1 с техническими деталями: платформа, протоколы, ограничения]
- [Функция 2 с привязкой к компонентам: УТМ, контроллер, служба]
- [Функция 3 с требованиями к надёжности]

## 7. Архитектурные требования
- **Целевая платформа**: [конкретика: Windows x86/x64, версии ОС]
- **Язык/платформа**: [конкретные версии: .NET Framework 4.7.2, .NET 6+ self-contained]
- **Особые ограничения**: [архитектурные нюансы: AnyCPU vs x86, shadow copying, IPC]

## 8. Интерфейс
[Описание изменений в UI/UX ServiceApp или iikoFront. Если изменений нет — укажи "Интерфейс полностью идентичен текущему, все элементы управления сохраняются"]

## 9. MVP: [Название эпика]
### **Что входит в MVP:**
- [Конкретные элементы реализации, которые закрывают основную боль]
- [Технические компоненты, обязательные для первого релиза]

### **Цели MVP:**
- [Измеримая бизнес-цель с метрикой]
- [Техническая цель с критерием успеха]"""

class AIClient:
    def __init__(self, api_key: str, base_url: str, model: str):
        self.api_key = api_key.strip()
        self.base_url = base_url.strip().rstrip("/")  # Убираем пробелы и лишний слэш
        self.model = model
        self.client = httpx.Client(timeout=120.0)  # Увеличим таймаут для больших эпиков
    
    def generate_epic(self, description: str) -> Optional[str]:
        try:
            logger.info(f"📝 Генерация эпика по запросу: '{description[:50]}...'")
            logger.info(f"🤖 Модель: {self.model}")
            
            response = self.client.post(
                f"{self.base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                    "HTTP-Referer": "http://localhost:5000",
                    "X-Title": "ShezGard Bot",
                },
                json={
                    "model": self.model,
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": f"Заполни эпик по шаблону на основе описания:\n\n{description}"},
                    ],
                    "temperature": 0.5,  # DeepSeek лучше работает с 0.5-0.7
                    "max_tokens": 6000,  # Увеличим лимит для развёрнутых эпиков
                    "reasoning": {"enabled": True},  # Включаем режим рассуждений для лучшей структуризации
                },
            )
            
            logger.info(f"📡 Статус ответа: {response.status_code}")
            
            # Если ошибка — выводим детали
            if response.status_code != 200:
                error_text = response.text[:1000]
                logger.error(f"❌ Ошибка API ({response.status_code}): {error_text}")
                return None
            
            data = response.json()
            result = data["choices"][0]["message"]["content"].strip()
            logger.info("✅ Эпик успешно сгенерирован!")
            return result
            
        except Exception as e:
            logger.exception(f"💥 Исключение при генерации эпика: {e}")
            return None
    
    def close(self):
        self.client.close()

# Инициализация клиента с новой моделью DeepSeek
ai_client = AIClient(
    api_key=os.getenv("OPENROUTER_API_KEY", ""),
    base_url=os.getenv("OPENROUTER_API_BASE", "https://openrouter.ai/api/v1"),
    model=os.getenv("MODEL_NAME", "deepseek/deepseek-v3.2"),  # ← НОВАЯ МОДЕЛЬ!
)

# ==================== Роуты ====================

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/generate", methods=["POST"])
def generate_epic():
    data = request.get_json()
    if not data or "description" not in data:
        return jsonify({"error": "Отсутствует поле 'description'"}), 400
    
    description = data["description"].strip()
    
    if not description:
        return jsonify({"error": "Описание не может быть пустым"}), 400
    
    if len(description) < 10:
        return jsonify({"error": "Описание слишком короткое (минимум 10 символов)"}), 400
    
    if len(description) > 2000:
        return jsonify({"error": "Описание слишком длинное (максимум 2000 символов)"}), 400
    
    logger.info("=" * 60)
    logger.info(f"📨 Новый запрос на генерацию эпика")
    logger.info(f"📝 Описание: {description[:100]}...")
    logger.info("=" * 60)
    
    epic = ai_client.generate_epic(description)
    
    if not epic:
        logger.error("❌ Не удалось сгенерировать эпик")
        return jsonify({"error": "Ошибка генерации эпика. Проверь консоль сервера для деталей."}), 500
    
    logger.info("✅ Отправляю эпик пользователю")
    return jsonify({"epic": epic})

@app.route("/api/health")
def health():
    return jsonify({
        "status": "ok",
        "message": "ShezGard Bot готов к работе!",
        "model": ai_client.model
    })

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Маршрут не найден"}), 404

@app.errorhandler(500)
def server_error(e):
    logger.exception("Внутренняя ошибка сервера")
    return jsonify({"error": "Внутренняя ошибка сервера"}), 500

# ==================== Запуск ====================

def cleanup():
    logger.info("🧹 Очистка ресурсов...")
    ai_client.close()

if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("🤖 ShezGard Bot — Веб-интерфейс")
    print("=" * 60)
    print(f"📍 Открой в браузере: http://localhost:5000")
    print(f"🧠 Модель: {ai_client.model}")
    print(f"🔧 Base URL: {ai_client.base_url}")
    print("🛑 Для остановки нажми Ctrl+C")
    print("=" * 60 + "\n")
    
    try:
        app.run(host="127.0.0.1", port=5000, debug=False)  # debug=False для продакшена
    except KeyboardInterrupt:
        print("\n🛑 Останавливаю сервер...")
    finally:
        cleanup()